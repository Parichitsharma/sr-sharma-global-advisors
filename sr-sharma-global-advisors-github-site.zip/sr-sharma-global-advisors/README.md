# S.R. Sharma Global Advisors LLC — Website

GitHub-ready static website inspired by the information architecture and premium advisory aesthetic of the reference site provided by the client, while using original copy, layout styling, and the client's own branding/photo assets.

## Files
- `index.html` — complete site
- `styles.css` — responsive design and animations
- `script.js` — navigation, scroll reveals, FAQ accordion, contact mailto
- `assets/` — supplied S.R. Sharma branding and founder photograph

## Publish on GitHub Pages
1. Create a new GitHub repository, e.g. `sr-sharma-global-advisors`.
2. Upload everything in this folder to the repository root.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**, choose `main` and `/ (root)`, then Save.
5. GitHub will publish the site at your Pages address.
6. For your own domain, add it under **Settings → Pages → Custom domain**, then configure the DNS records GitHub gives you.

## Before launch
- Replace the mailto address in `script.js` if you want enquiries to go to a different business email.
- Review the wording of professional credentials and services for legal/regulatory accuracy before publishing.
